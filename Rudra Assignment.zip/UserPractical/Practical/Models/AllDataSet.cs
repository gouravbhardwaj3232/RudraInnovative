﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Practical.Models
{
    public class AllDataSet
    {
        public SqlConnection con = new SqlConnection();
        public AllDataSet()
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        
        }
        public DataTable ExecuteSql(string QryWithParameter, Hashtable ht)
        {
            DataTable tb = new DataTable();
            if (con.State == ConnectionState.Closed)
                con.Open();

            SqlCommand cmd = new SqlCommand(QryWithParameter, con);
            try
            {

                foreach (DictionaryEntry d in ht)
                    cmd.Parameters.Add((string)d.Key, d.Value);

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(tb);
                cmd.Dispose();
                adp.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                cmd.Dispose();
                con.Close();
                throw ex;
            }
            return tb;
        }
        public DataTable GetDataTable(string sp, Hashtable ht)
        {
            DataTable dt = new DataTable();
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(sp, con);
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (DictionaryEntry d in ht)
                    cmd.Parameters.Add((string)d.Key, d.Value);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                con.Close();

                throw (ex);
            }
            finally
            {
                //Connection.Close();
            }
            return dt;
        }
    }
}