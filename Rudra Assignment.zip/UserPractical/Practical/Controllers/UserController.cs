﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using webApiTest.Models;
using Practical.Models;
namespace Practical.Controllers
{
    [BasicAuthentication]
    public class UserController : ApiController
    {

        AllDataSet DataSet = new AllDataSet();
        [HttpPost]
        public UserListResponseList Saveuser(Userrequest request)
        {
            Hashtable ht = new Hashtable();
            UserListResponseList response = new UserListResponseList();
            try
            {

                ht.Add("@Name", request.Name);
                ht.Add("@CompanyName", request.CompanyName);
                ht.Add("@Address", request.Address);
                ht.Add("@City", request.City);
                ht.Add("@Country", request.Country);
                ht.Add("@Designation", request.Designation);
                ht.Add("@Email", request.Email);
                ht.Add("@Mobile", request.Mobile);
                ht.Add("@password", request.Password);
                DataSet.GetDataTable("SP_Saveuserdetail", ht);
                ht.Clear();
                response.Message = "Success";
                response.Status = "1";
            }
            catch (Exception ex)
            {
                response.Status = "0";
                response.Message = ex.Message.ToString();
            }
            return response;
        }
        [HttpPost]
        public UpdateUserresponse Updateuser(UpdateUserrequest request)
        {
            DataTable dt = new DataTable();
            Hashtable ht = new Hashtable();
            UpdateUserresponse response = new UpdateUserresponse();
            try
            {

                ht.Add("@Name", request.Name);
                ht.Add("@Company", request.CompanyName);
                ht.Add("@Address", request.Address);
                ht.Add("@City", request.City);
                ht.Add("@Country", request.Country);
                ht.Add("@Designation", request.Designation);
                ht.Add("@Email", request.Email);
                ht.Add("@Mobile", request.Mobile);
                ht.Add("@password", request.Password);
                ht.Add("@userid", request.UserId);
                dt = DataSet.GetDataTable("SP_updateuserdetail", ht);
                ht.Clear();
                if (dt.Rows.Count > 0)
                {
                    response.Email = dt.Rows[0]["Email"].ToString();
                    response.Name = dt.Rows[0]["Name"].ToString();
                    response.UserId = Convert.ToInt32(dt.Rows[0]["userid"]);
                    response.Mobile = dt.Rows[0]["Mobile"].ToString();
                    response.CompanyName = dt.Rows[0]["CompanyName"].ToString();
                    response.Address = dt.Rows[0]["Address"].ToString();
                    response.City = dt.Rows[0]["City"].ToString();
                    response.Country = dt.Rows[0]["Country"].ToString();
                    response.Designation = dt.Rows[0]["Designation"].ToString();
                    response.Message = "Success";
                    response.Status = "1";
                }
                else
                {
                    response.Message = "data not updated";
                    response.Status = "1";
                }
               
                dt.Clear();
            }

            catch (Exception ex)
            {
                response.Status = "0";
                response.Message = ex.Message.ToString();
            }
            return response;
        }
        [HttpPost]
        public ForgotpasswordResponse Deleteuser(DeleteRequest request)
        {
            DataTable dt = new DataTable();
            Hashtable ht = new Hashtable();
            ForgotpasswordResponse response = new ForgotpasswordResponse();
            try
            {
                ht.Add("@userid", request.userid);
                DataSet.ExecuteSql("delete from NewUsermaster where userid=@userid", ht);
                response.Message = "Success";
                response.Status = "1";
                ht.Clear();
            }

            catch (Exception ex)
            {
                response.Status = "0";
                response.Message = ex.Message.ToString();
            }
            return response;
        }
        [HttpPost]
        public ForgotpasswordResponse ForgotPassword(ForgotpasswordRequest request)
        {
            Hashtable ht = new Hashtable();
            ForgotpasswordResponse response = new ForgotpasswordResponse();
            try
            {
                ht.Add("Email", request.Email);
                ht.Add("Password", request.Password);
                DataSet.GetDataTable("SP_ForgotPassword", ht);
                response.Message = "Success";
                response.Status = "1";
                ht.Clear();
            }
            catch (Exception ex)
            {
                response.Status = "0";
                response.Message = ex.Message.ToString();
            }
            return response;
        }
        [HttpPost]
        public loginResponse UserLogin(loginRequest req)
        {
            DataTable dt = new DataTable();
            Hashtable ht = new Hashtable();
            loginResponse response = new loginResponse();
            try
            {
                ht.Add("Email", req.Email);
                ht.Add("Password", req.Password);
                dt = DataSet.GetDataTable("SP_Userlogin", ht);
                if (dt.Rows.Count > 0)
                {
                    response.Email = dt.Rows[0]["Email"].ToString();
                    response.Name = dt.Rows[0]["Name"].ToString();
                    response.Userid = Convert.ToInt32(dt.Rows[0]["userid"]);
                    response.Mobile = dt.Rows[0]["Mobile"].ToString();
                    response.Message = "Success";
                    response.Status = "1";
                }
                else
                {
                    response.Message = "user not found";
                    response.Status = "1";
                }
                ht.Clear();
                dt.Clear();
            }

            catch (Exception ex)
            {
                response.Status = "0";
                response.Message = ex.Message.ToString();
            }
            return response;
        }
    }
}
